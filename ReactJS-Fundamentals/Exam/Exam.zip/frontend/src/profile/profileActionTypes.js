export const MINE_LOAD = 'MINE_LOAD'

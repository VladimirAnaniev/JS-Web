export const STATS_SET = 'STATS_SET'
